﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WinForm_Fractals_KDZ_MF
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            int wid = SystemInformation.PrimaryMonitorSize.Width;
            int heig = SystemInformation.PrimaryMonitorSize.Height;
            centr_m.D1.X = pictureBox1.Width / 2;
            centr_m.D1.Y = pictureBox1.Height / 2;
            MinimumSize = new Size(wid / 2, heig / 2); // установка минимальных значений окна
            height_ = pictureBox1.Height / 2; // начальные значения высоты и ширины, равные центру отображаемого окна
            width_ = pictureBox1.Width / 2;
            comboBox4.Visible = false; // настройка 
            label6.Visible = false;

            mainbit = new Bitmap(1000, 1000);
            maingraphics = Graphics.FromImage(mainbit); // графика и битмап для сохранения картинки
            maingraphics.Clear(Color.White);
        }

        public static Bitmap mainbit;// графика для сохранения картинки
        public static Graphics maingraphics;
        int whichfractal; // номер текущего фрактала
        int depth; // текущая максимальная глубина рекурсии
        static int depth2; // дополнительная глубина для постройки фракталов
        n_fractal nf = new n_fractal();
        kvaziklever kvazi = new kvaziklever(); // строим первичные объекты классов
        centr_mass centr_m = new centr_mass();
        public static int GetDepth { get => depth2; }


        float deltaX = 0;
        float deltaY = 0;
        float oldX = 0;
        float oldY = 0;
        int rMax;
        int rMin;
        int gMax;
        int gMin;
        int bMax;
        int bMin;
        public float height_;
        public float width_;
        public static List<Color> colorList = new List<Color>();
        bool exist = false;
        
        public static Color colorforPen(int n) => colorList[n];
   
        /// <summary>
        /// Устанавливает глубину для отрисовки массива и количества цветов в гамме
        /// </summary>
        /// <returns>возврещает true, если введено корректное значение, false в обратном</returns>
        public bool Depth()
        {
            if (!int.TryParse(textBox1.Text, out depth) || depth < 1)
            {
                MessageBox.Show("Ошибка задания глубины рекурсии!");
                return false;
            }
            
            else
            {
                if (depth > 10||depth<1) depth = 10; // максимальная отрисовка - 10. Далее не видна разница.
                nf.MaxRecursion = depth;
                kvazi.MaxRecursion = depth; 
                centr_m.MaxRecursion = depth;
                depth2 = depth;
                return true;
            }
           
        }
        /// <summary>
        /// устанавливает цветовой градиент длиной в глубину рекурсии
        /// </summary>
        /// <param name="size"> глубина рекурсии</param>
        public void Colors(int size)
        {
            rMax = button3.BackColor.R;
            rMin = button2.BackColor.R;
            gMax = button3.BackColor.G;
            gMin = button2.BackColor.G;
            bMax = button3.BackColor.B;
            bMin = button2.BackColor.B;
            colorList.Clear();
            colorList.Add(Color.FromArgb(rMin, gMin, bMin)); // первый цвет - исходный
            for (int i = 1; i < size-1; i++)
            {
                var rAverage = rMin + ((rMax - rMin) * i / size); 
                var gAverage = gMin + ((gMax - gMin) * i / size); // size - 2 генерируемые
                var bAverage = bMin + ((bMax - bMin) * i / size);
                colorList.Add(Color.FromArgb(rAverage, gAverage, bAverage)); // последний цвет - исходный 
            }
            colorList.Add(Color.FromArgb(rMax, gMax, bMax));
        }

        /// <summary>
        /// кнопка "Построить" - строит график в центре видимой площади
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            
            height_ = pictureBox1.Height/2; //высота элемента pictureBox1
            width_ = pictureBox1.Width/2; // ширина 

            Graphics pic = pictureBox1.CreateGraphics();
            pic.Clear(Color.White); // очистка поля

            if (comboBox4.SelectedIndex != 0 && comboBox4.SelectedIndex != 1 && comboBox4.SelectedIndex != 2 && comboBox4.SelectedIndex != 3 && listBox1.SelectedIndex==1)
            {
                MessageBox.Show("По умолчанию незадействованной будет выбрана правая сторона");
            } // Для Квазиклевера - если пользователь не выбрал свободную сторону

            if (Depth() && (comboBox1.SelectedIndex == 0 || comboBox1.SelectedIndex == 1|| comboBox1.SelectedIndex == 2 || comboBox1.SelectedIndex==3)) 
            {
                exist = true;
                Colors(depth); // определение цветов
                SelectSize(); 
                switch (listBox1.SelectedIndex)
                {
                    case 0:
                        {
                            
                            whichfractal = 0;
                            ClearView();                            
                            nf.draw(width_, height_, nf.length, 1, nf.MaxRecursion, pictureBox1);
                          
                            break;
                        }
                    case 1:
                        {
                            whichfractal = 1;
                            ClearView();
                            kvazi.draw(width_, height_, kvazi.length, kvazi.side, kvazi.MaxRecursion, pictureBox1);

                        }
                        break;
                    case 2:
                        {
                            whichfractal = 2;
                            ClearView();
                            centr_m.draw(width_, height_, 1, 1, centr_m.MaxRecursion, pictureBox1);
                        }
                        break;

                }

            }

            if (comboBox1.SelectedIndex != 0 && comboBox1.SelectedIndex != 1 && comboBox1.SelectedIndex != 2 && comboBox1.SelectedIndex!=3)
            {
                MessageBox.Show("Выберите увеличение!");
            } // проверка на выбор увеличения
           
        }

        /// <summary>
        /// метод отрисовки picturebox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void pictureBox1_Paint(object sender, PaintEventArgs e)
        {
        }
        /// <summary>
        /// выбор начального цвета из палитры
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                button2.BackColor = colorDialog1.Color; // устанавливаем цвет клавиши в выбранный нами
            }
        }
        /// <summary>
        /// выбор конечного цвета из палитры
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button3_Click(object sender, EventArgs e)
        {
            if (colorDialog2.ShowDialog() == DialogResult.OK)
            {
                button3.BackColor = colorDialog2.Color;// устанавливаем цвет клавиши в выбранный нами
            }
        }

        /// <summary>
        /// изменение выбранного фрактала устанавливает видимость индивидуальных настроек -
        /// для квазифрактала появляется возможность выбора пустой стороны
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == 0)
            {
                label6.Visible = false;
                comboBox4.Visible = false;
            }
            else if (listBox1.SelectedIndex == 1)
            {
                label6.Visible = true;
                comboBox4.Visible = true;
            }
            else if (listBox1.SelectedIndex == 2)
            {
                label6.Visible = false;
                comboBox4.Visible = false;
            }
        }
        /// <summary>
        /// запись начальных значений координат мыши при нажатии на picturebox
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (exist)
            {
                oldX = Cursor.Position.X;
                oldY = Cursor.Position.Y;
            }
            else { MessageBox.Show("Создайте фрактал!"); }
        }
        /// <summary>
        /// изменение положения центра фрактала с последующей его отрисовкой в этой точке
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            deltaX = oldX - Cursor.Position.X;
            deltaY = oldY - Cursor.Position.Y;
            width_ -= deltaX;
            height_ -= deltaY;
            if (exist)
            {
                ClearView();
                switch (whichfractal)
                {
                    case 0: nf.draw(width_, height_, nf.length, 1, nf.MaxRecursion, pictureBox1); break;
                    case 1: kvazi.draw(width_, height_, kvazi.length, kvazi.side, kvazi.MaxRecursion, pictureBox1); break;
                    case 2: centr_m.draw(width_, height_, 1, 1, centr_m.MaxRecursion, pictureBox1); break;
                }
            }
            else { MessageBox.Show("Создайте фрактал!"); }
        }
        /// <summary>
        /// метод очистки видимой части picturebox для новой отрисовки
        /// </summary>
        private void ClearView()
        {
            Graphics pic = pictureBox1.CreateGraphics();
            pic.Clear(Color.White);
            //Colors(depth);
        }
        /// <summary>
        /// установка увеличения фрактала - увеличение значимой части отрисовки
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>

        private void SelectSize()
        {
            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    {
                        if (Depth())
                        {
                            nf.length = 100;
                            kvazi.length = 50;
                            centr_m.length = 2;
                        }
                    }
                    break;
                case 1:
                    {
                        if (Depth())
                        {
                            nf.length = 200;
                            kvazi.length = 100;
                            centr_m.length = 4;
                        }
                    }
                    break;
                case 2:
                    {
                        if (Depth())
                        {
                            nf.length = 300;
                            kvazi.length = 150;
                            centr_m.length = 6;
                        }
                    }
                    break;
                case 3:
                    {
                        if (Depth())
                        {
                            nf.length = 500;
                            kvazi.length = 250;
                            centr_m.length = 10;
                        }
                    }
                    break;
            }

        }
        /// <summary>
        /// Перерисовка фрактала после изменения размера
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_ResizeEnd(object sender, EventArgs e)
        {
            if (exist)
            {
                ClearView();
                switch (whichfractal)
                {
                    case 0: nf.draw(width_, height_, nf.length, 1, nf.MaxRecursion, pictureBox1); break;
                    case 1: kvazi.draw(width_, height_, kvazi.length, kvazi.side, kvazi.MaxRecursion, pictureBox1); break;
                    case 2: centr_m.draw(width_, height_, 1, 1, centr_m.MaxRecursion, pictureBox1); break;
                }
            } 

        }
        /// <summary>
        /// перерисовка при максимизации
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_SizeChanged(object sender, EventArgs e)
        {
            if (WindowState == FormWindowState.Minimized)
            {
                ClearView();
                if (exist)
                {
                    switch (whichfractal)
                    {
                        case 0: nf.draw(width_, height_, nf.length, 1, nf.MaxRecursion, pictureBox1); break;
                        case 1: kvazi.draw(width_, height_, kvazi.length, kvazi.side, kvazi.MaxRecursion, pictureBox1); break;
                        case 2: centr_m.draw(width_, height_, 1, 1, centr_m.MaxRecursion, pictureBox1); break;
                    }
                }
            }
        }

        /// <summary>
        /// изменение незадействованной стороны квазиклевера
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            kvazi.side = comboBox4.SelectedIndex;
        }
        /// <summary>
        /// Сохранение картинки. Возможны 2 варианта : Jpeg и Png. Сохраняется увеличенная область, нежели область видимости,
        /// для большего захвата отрисованного фрактала. Цвет фона - белый.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button4_Click(object sender, EventArgs e)
        {
            if (exist)
            {
                Bitmap bitmapImageOfFractal = new Bitmap(pictureBox1.Width, pictureBox1.Height);
                SaveFileDialog saveImage = new SaveFileDialog();
                saveImage.Filter = "JPeg Format (*.jpeg)|*.jpeg|PNG Format (*.png)|*.png";
                saveImage.Title = "Сохранить фрактал как изображение";
                pictureBox1.DrawToBitmap(bitmapImageOfFractal, new Rectangle(0, 0, pictureBox1.Width, pictureBox1.Height));

                maingraphics.Clear(Color.White);
                ClearView();
                switch (whichfractal)
                {
                    case 0: nf.draw(width_, height_, nf.length, 1, nf.MaxRecursion, pictureBox1); break;
                    case 1: kvazi.draw(width_, height_, kvazi.length, kvazi.side, kvazi.MaxRecursion, pictureBox1); break;
                    case 2: centr_m.draw(width_, height_, 1, 1, centr_m.MaxRecursion, pictureBox1); break;
                }

                if (saveImage.ShowDialog() == DialogResult.OK) //для избавления от исключения в случае нажатия на кнопку "Отмена"
                {
                    if (saveImage.FileName != "")
                    {
                        FileStream fs = (FileStream)saveImage.OpenFile();
                        switch (saveImage.FilterIndex)
                        {
                            case 1:
                                mainbit.Save(fs, ImageFormat.Jpeg);
                                break;
                            case 2:
                                mainbit.Save(fs, ImageFormat.Png);
                                break;
                        }
                        fs.Close();
                        MessageBox.Show("Файл успешно сохранен! ", "Cохранение", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }
            else { MessageBox.Show("Создайте фрактал!"); } // Проверка! 
        }
    }

    public abstract class fractal 
    { 
        public float length; // длина значимой части
        public Color startColor; // начальный цвет
        public Color endColor; // конечный цвет
        public int currentRecursion; // текущая глубина рекурсии
        public int MaxRecursion; // глубина рекурсии, задаваемая полем depth
        public abstract void draw(float x1, float y1, float razm_f, int numrec, int maxrec, PictureBox pb);//основной метод отрисовки
    }
    /// <summary>
    /// класс "Н-Фрактала"
    /// </summary>
    public class n_fractal : fractal
    {/// <summary>
     /// </summary>
     /// <param name="x1">значение Width</param>
     /// <param name="y1">значение Height</param>
     /// <param name="razm_f">размер одной линии</param>
     /// <param name="numrec">текущая глубина рекурсии</param>
     /// <param name="maxrec">максимальная глубина рекурсии </param>
     /// <param name="pb">picturebox для отрисовки</param>
        public override void draw(float x1, float y1, float razm_f, int numrec, int maxrec, PictureBox pb)
        {
            //вершины фигуры Н
            float x11; float y11;
            float x01; float y01;
            float x00; float y00;
            float x10; float y10;
            x11 = x1 + razm_f;
            y11 = y1 + razm_f;
            x01 = x1 - razm_f;
            y01 = y1 + razm_f;//задаем 4 новых значения (х,у), и создаем рекурсию,
            x10 = x1 + razm_f;//вызывая эту же функцию в этих 4 точках.
            y10 = y1 - razm_f;
            x00 = x1 - razm_f;
            y00 = y1 - razm_f;

            H(x1, y1, razm_f, pb, numrec - 1);//рисуем одну фигуру Н
            numrec++;
            razm_f = razm_f / 2;//уменьшаем размер в 2 раза
                                // если размер не меньше минимального, то рисуем в 4-х вершинах
            if (maxrec >= numrec)
            {
                draw(x11, y11, razm_f, numrec, maxrec, pb);
                draw(x01, y01, razm_f, numrec, maxrec, pb);
                draw(x10, y10, razm_f, numrec, maxrec, pb);
                draw(x00, y00, razm_f, numrec, maxrec, pb);
            }
            
        }
        /// <summary>
        /// отрисовка одной буквы Н
        /// </summary>
        /// <param name="x">значение Width центра будущей фигуры </param>
        /// <param name="y">значение Height центра будущей фигуры</param>
        /// <param name="razmer">уменьшенный размер одной линии</param>
        /// <param name="pb">объект для отрисовки</param>
        /// <param name="numrec">текущая глубина рекурсии</param>
        protected void H(float x, float y, float razmer, PictureBox pb, int numrec)//функция отрисовки одной Н
        {
            Pen myPen = new Pen(Form1.colorforPen(numrec), 2);
            Graphics g = Graphics.FromHwnd(pb.Handle);
            // графика для сохранения
           Form1.maingraphics.DrawLine(myPen, x - razmer, y - razmer, x - razmer, y + razmer);
           Form1.maingraphics.DrawLine(myPen, x - razmer, y, x + razmer, y);
           Form1.maingraphics.DrawLine(myPen, x + razmer, y - razmer, x + razmer, y + razmer);
            // Рисуем в нужной нам графике
            g.DrawLine(myPen, x - razmer, y - razmer, x - razmer, y + razmer);
            g.DrawLine(myPen, x - razmer, y, x + razmer, y);
            g.DrawLine(myPen, x + razmer, y - razmer, x + razmer, y + razmer);
        }
    }
    /// <summary>
    /// класс фрактала "Квазиклевер"
    /// </summary>
    public class kvaziklever : fractal
    {
        public int side; // неиспользуемая сторона
        /// <summary>
        /// рекурсивная отрисовка фигуры квазиклевера
        /// </summary>
        /// <param name="x1">значение Width центра будущей фигуры </param>
        /// <param name="y1">значение Height центра будущей фигуры</param>
        /// <param name="razm_f">радиус круга</param>
        /// <param name="numrec">текущая глубина рекурсии</param>
        /// <param name="maxrec">максимальная глубина рекурсии</param>
        /// <param name="pb">объект для отрисовки</param>
        public override void draw(float x1, float y1, float razm_f, int numrec, int maxrec, PictureBox pb)
        {
           //создадим графику из передаваемого picturebox
            Graphics g = pb.CreateGraphics();
            SolidBrush s = new SolidBrush(Form1.colorforPen(Form1.GetDepth-maxrec));

            g.FillEllipse(s, x1 - razm_f, y1 - razm_f, 2 * razm_f, 2 * razm_f);
            Form1.maingraphics.FillEllipse(s, x1 - razm_f, y1 - razm_f, 2 * razm_f, 2 * razm_f);
            if (maxrec != 1)
            {
                float[] x = new float[4];
                float[] y = new float[4];
                float d = 3 * razm_f / 2;
                x[0] = x1 - d;
                y[0] = y1;
                x[1] = x1;
                y[1] = y1 - d;
                x[2] = x1 + d;
                y[2] = y1;
                x[3] = x1;
                y[3] = y1 + d;
                

                for (int i = 0; i < 4; i++)
                { // рисуем на всех сторонах, кроме родительского
                    if (i - numrec == 2 || i - numrec == -2)
                       continue;
                    draw(x[i], y[i], razm_f / 2, i, maxrec - 1,pb);
                }
            }
        }
    }
    /// <summary>
    /// класс фрактала "Центр масс"
    /// </summary>
    public class centr_mass : fractal
    {
       public PointF D1;
       protected PointF A;
       protected PointF B;
       protected PointF C;
        /// <summary>
        /// запуск рекурсивной функции отрисовки фрактала 
        /// </summary>
        /// <param name="x1">значение Width центра будущей фигуры </param>
        /// <param name="y1">значение Height центра будущей фигуры</param>
        /// <param name="razm_f">радиус круга</param>
        /// <param name="numrec">текущая глубина рекурсии</param>
        /// <param name="maxrec">максимальная глубина рекурсии</param>
        /// <param name="pb">объект для отрисовки</param>
        public override void draw(float x1, float y1, float razm_f, int numrec, int maxrec, PictureBox pb)
        {
            D1.X = x1;
            D1.Y = y1;
            // для удобной смены координат и перерисовки треугольника, мы подсчитываем численные зависимости координат 
            //точек (А,В,С) от фактического центра масс D(х1,у1). Таким образом мы во многом упрощаем код и структуру метода.
            A = new PointF(D1.X + 50f*length, D1.Y + 28.8675f*length);
            B = new PointF(D1.X - 50f * length, D1.Y + 28.8675f * length);
            C = new PointF(D1.X, D1.Y - 57.735f * length);
            
            Graphics g = pb.CreateGraphics();
            Pen myPen = new Pen(Form1.colorforPen(numrec-1), 2);
            

            g.DrawLine(myPen, A.X, A.Y, B.X, B.Y);
            g.DrawLine(myPen, B.X, B.Y, C.X, C.Y);
            g.DrawLine(myPen, A.X, A.Y, C.X, C.Y);


           Form1.maingraphics.DrawLine(myPen, A.X, A.Y, B.X, B.Y);
           Form1.maingraphics.DrawLine(myPen, B.X, B.Y, C.X, C.Y);
           Form1.maingraphics.DrawLine(myPen, A.X, A.Y, C.X, C.Y);

            drawTriangle(A, B, C, maxrec-1,pb);
        }
        /// <summary>
        /// Отрисовка векторов к центру масс у 1 треугольника
        /// </summary>
        /// <param name="A">координаты точки А</param>
        /// <param name="B">координаты точки В</param>
        /// <param name="C">координаты точки С</param>
        /// <param name="maxrec">глубина текущей рекурсии</param>
        /// <param name="pb">объект для отрисовки</param>
        protected void drawTriangle(PointF A, PointF B, PointF C, int maxrec, PictureBox pb)
        {
            if (maxrec != 0)
            {
                PointF D = new PointF();    //Точка центра масс
                PointF v1 = new PointF();   //Вектор AB
                PointF v2 = new PointF();   //Вектор AC

                //Вектор АB
                v1.X = B.X - A.X;
                v1.Y = B.Y - A.Y;

                //Вектор AC
                v2.X = C.X - A.X;
                v2.Y = C.Y - A.Y;

                D.X = A.X + (v1.X + v2.X) / 3;     //К точке А прибавим сумму векторов AВ и AC, деленную на 3
                D.Y = A.Y + (v1.Y + v2.Y) / 3;     //и получим координаты центра масс

                Pen myPen = new Pen(Form1.colorforPen(Form1.GetDepth - maxrec), 2);
               
                Graphics g = Graphics.FromHwnd(pb.Handle);

                g.DrawLine(myPen, A.X, A.Y, D.X, D.Y);    //Рисуем отрезки от вершин к центру масс
                g.DrawLine(myPen, B.X, B.Y, D.X, D.Y);
                g.DrawLine(myPen, C.X, C.Y, D.X, D.Y);

                Form1.maingraphics.DrawLine(myPen, A.X, A.Y, D.X, D.Y);    //Рисуем отрезки от вершин к центру масс
                Form1.maingraphics.DrawLine(myPen, B.X, B.Y, D.X, D.Y);
                Form1.maingraphics.DrawLine(myPen, C.X, C.Y, D.X, D.Y);

                drawTriangle(A, B, D, maxrec - 1,pb);    //Вызываем рекурсивно процендуру для полученных 
                drawTriangle(B, C, D, maxrec - 1,pb);    //треугольников, с итерацией, меньшей на 1
                drawTriangle(A, C, D, maxrec - 1,pb);
            }
        }
        
    }
}
